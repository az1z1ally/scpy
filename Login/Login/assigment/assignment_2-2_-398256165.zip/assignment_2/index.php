<?php

echo "
<html>
<title>Index</title>
<head></head>
<body>
<a href='/login.php'>Please log in to your account here</a>
</body>
</html>
";

?>
 