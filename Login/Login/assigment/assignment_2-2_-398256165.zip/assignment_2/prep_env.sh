#!/bin/bash

sudo apt-get update
sudo apt-get -y dist-upgrade

sudo apt-get install -y openssh-server php python3-paramiko

mkdir ~/assign_2
mkdir ~/assign_2/server_1
mkdir ~/assign_2/server_2
mkdir ~/assign_2/server_3
mkdir ~/assign_2/server_4
mkdir ~/assign_2/server_5

cp index.php ~/assign_2/server_1
cp login.php ~/assign_2/server_1
sed -i 's/thispasswordwillwork/rockyou/g' ~/assign_2/server_1/login.php

cp index.php ~/assign_2/server_3
cp login.php ~/assign_2/server_3
sed -i 's/thispasswordwillwork/phreak/g' ~/assign_2/server_3/login.php

cp index.php ~/assign_2/server_5
cp login.php ~/assign_2/server_5
sed -i 's/thispasswordwillwork/dualcore/g' ~/assign_2/server_5/login.php


