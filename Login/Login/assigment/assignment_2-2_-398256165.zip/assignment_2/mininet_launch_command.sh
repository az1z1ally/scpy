sudo mn --topo single,6 --test pingall --post assignment_2_cmds.txt 
